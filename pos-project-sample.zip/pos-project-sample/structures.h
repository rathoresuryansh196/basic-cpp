using namespace std;

struct Item {
    string name;
    int quantity;
    double price;
};
