#include "structures.h"

Item *items;

string *serials;

Item newItem;

int idx = 0, quantity, no, count;

char option, command, confirm;

string serial, name, value;

double price;

bool redo, write;


